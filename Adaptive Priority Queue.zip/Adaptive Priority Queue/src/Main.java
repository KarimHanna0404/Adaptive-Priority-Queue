
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		  	System.out.println("APQ Tests\n");

		    APQ<Integer, String> apq = new APQ<>(true); 

		    System.out.println("Inserting into MinHeap");
		    apq.insert(5, "A");
		    apq.insert(3, "B");
		    apq.insert(7, "C");

		    System.out.println("Top (MinHeap): " + apq.top().getKey()); 

		    System.out.println("Toggling to MaxHeap");
		    apq.toggle();

		    System.out.println("Top (MaxHeap): " + apq.top().getKey()); 

		    System.out.println("Inserting more elements to test resize");
		    apq.insert(10, "D");
		    apq.insert(1, "E");
		    apq.insert(2, "F");
		    apq.insert(9, "G");
		    apq.insert(6, "H");
		    apq.insert(4, "I");

		    System.out.println("Heap size after insertions: " + apq.size()); 

		    System.out.println("peekAt(1): " + apq.peekAt(1).getKey()); 
		    System.out.println("peekAt(3): " + apq.peekAt(3).getKey()); 

		    System.out.println("Testing replaceKey");
		    APQ.Entry<Integer, String> removedTop = apq.removeTop(); 
		    apq.insert(6, "H");
		    APQ.Entry<Integer, String> e = apq.top(); 
		    apq.replaceKey(e, 11);
		    System.out.println("New top after replaceKey: " + apq.top().getKey()); 

		    System.out.println("Testing replaceValue");
		    String oldVal = apq.replaceValue(e, "Z");
		    System.out.println("Old value: " + oldVal); 

		    System.out.println("Testing peekAt() out of bounds");
		      try {
		         apq.peekAt(100);
		      } catch (IndexOutOfBoundsException ex) {
		         System.out.println("Caught expected exception: " + ex.getMessage());
		      }

		        System.out.println("Testing remove(e)");
		        APQ.Entry<Integer, String> toRemove = null;
		    for (int i = 0; i < apq.size(); i++) {
		         if (apq.peekAt(i + 1).getKey() == 4) {
		             toRemove = apq.peekAt(i + 1);
		             break;
		          }
		      }
		    if (toRemove != null) {
		        apq.remove(toRemove);
		    System.out.println("Removed key 4 successfully.");
		    } else {
		    System.out.println("Key 4 not found to remove.");
		    }

		    System.out.println("Testing merge with another APQ");
		    APQ<Integer, String> apq2 = new APQ<>(false); 
		    apq2.insert(20, "X");
		    apq2.insert(15, "Y");

		    if (!apq.state().equals("Max")) apq.toggle();
		    apq.merge(apq2);
		    System.out.println("Top after merge: " + apq.top().getKey()); 

		    System.out.println("\nTests Completed");
		    }
		}
	


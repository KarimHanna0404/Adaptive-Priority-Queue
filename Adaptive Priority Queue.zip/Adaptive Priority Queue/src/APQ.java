import java.util.Arrays;
import java.util.Comparator;
import java.util.NoSuchElementException;

public class APQ<K extends Comparable<K>, V> {

    private int size = 0;
    private Entry<K, V>[] heap;
    private boolean isMinHeap;

    // Constructor with initial capacity
    public APQ(boolean isMinHeap) {
        this.isMinHeap = isMinHeap;
        this.heap = (Entry<K, V>[]) new Entry[10]; // default capacity
    }

    public void toggle() {
        //if isMinHeap == true -> it becomes false thus it is a max heap
        //if isMinHeap == false -> it becomes true thus it is a minHeap
        isMinHeap = !isMinHeap;
        //reheap the entire heap , i = (size/2)-1 because in a binary heap all nodes from size/2 to size-1 are leaves which do not need to be reheapified
        for(int i = (size / 2)-1;i>=0;i--) {
            downHeap(i);
        }
    }

    //doubling the size of the heap, helper method for conditions where resizing the heap is important
    public void resize() {
        Entry<K, V>[] newHeap = (Entry<K, V>[]) new Entry[heap.length * 2];
        for (int i = 0; i < heap.length; i++) {
            newHeap[i] = heap[i];
        }
        heap = newHeap;
    }

    public Entry<K, V> removeTop() {
        //there are no Entries and thus return null
        if(size == 0) {
            return null;
        }

        Entry<K, V> removed = heap[0];
        //move the last element to the root
        heap[0] = heap[size-1];
        heap[size-1] = null; //clearing the last spot
        size--;
        //restoring heap
        downHeap(0);
        return removed;
    }

    public void insert(K key, V value) {
        //if the size of the heap is full double it
        if (size == heap.length) {
            resize();
        }
        Entry<K, V> newEntry = new Entry<>(key, value);
        //placing the entry at the end of the heap
        heap[size] = newEntry;
        //rearrange the heap if needed aswell as checks automatically using the upheap method if its a minHeap or maxHeap and changes accordingly
        //we call upHeap only and not downHeap because when we insert a new element you always place it at the end of the heap or at the next available index in the array (which is at the end of the array)
        upHeap(size);
        size++;

    }

    public Entry<K, V> top() {
        //empty
        if(isEmpty()) {
            return null;
        }

       return heap[0];
    }

    public Entry<K, V> remove(Entry<K, V> entry) {
        int index = -1;
        //Finding the index of the entry to remove
        for (int i = 0; i < size; i++) {
            if (heap[i].equals(entry)) {
                index = i;
                break;
            }
        }
        //entry not found
        if (index == -1) {
            return null;
        }

        //Store the removed entry to return it later
        Entry<K, V> removed = heap[index];

        // Step 4: Replace with the last element
        heap[index] = heap[size - 1];
        heap[size - 1] = null;
        size--;

        //Restoring heap property, we use downheap and upheap because we dont know where the Entry that we are trying to remove is located in the heap, if the entry is too big for the parent it should go down hense using downheap and if the entry is too small for the parent it should go up and thus it should use upheap
        downHeap(index);
        upHeap(index);

        //Return the removed entry
        return removed;
    }
    public K replaceKey(Entry<K, V> entry, K newKey) {
        //start by finding the key in heap
        int index = -1;
       for(int i = 0; i < size; i++) {
           if (heap[i].equals(entry)) {
               index = i;
               break;
           }
       }

       //element not found in the heap
       if (index == -1) {
           throw new NoSuchElementException("Element not found at index" +index);
       }

       K removed = heap[index].getKey();
       heap[index].setKey(newKey);

       //heapify
       upHeap(index);
       downHeap(index);

       return removed;
    }

    public V replaceValue(Entry<K, V> entry, V newValue) {
        V oldValue = entry.getValue();
        entry.setValue(newValue);
        return oldValue;
    }

    public String state() {
        if(isMinHeap) {
            return "Min";
        }
        else {
            return "Max";
        }
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public int size() {
        return size;
    }

    public Entry<K, V> peekAt(int n) {
        //validating the user input to be within the bounds of the heap
        if(n< 1 || n > size) {
            throw new IndexOutOfBoundsException("invalid position at index "+ n);
        }
        //we are creating a new array temp that holds only the actual entries that are a part of the heap while ignoring the nulls to avoid a nullpointerException and since we only care about entries in this case and not nulls
        Entry<K, V>[] temp = (Entry<K, V>[]) new Entry[size];
        for (int i = 0; i < size; i++) {
            temp[i] = heap[i];
        }
        //if we are in a MinHeap we sort from ascending order (smallest to largest by key)
        if(isMinHeap) {
            Arrays.sort(temp, new Comparator<Entry<K, V>>() {
                //inner class compare, checks if o1<o2's key-> returns negative
               public int compare(Entry<K, V> o1, Entry<K, V> o2) {
                   return o1.getKey().compareTo(o2.getKey());
               }
            });
        }
        //if we are in a MaxHeap mode then we sort from descending order (largest to smallest)
        else{
            Arrays.sort(temp, new Comparator<Entry<K, V>>() {
                //inner class compare checks if o2's key<o1's key -> returns negative
               public int compare(Entry<K, V> o1, Entry<K, V> o2) {
                   return o2.getKey().compareTo(o1.getKey());
               }
            });
        }
        //1 based index that is why we substract 1
        return temp[n-1];
    }

    public void merge(APQ<K, V> other) {
        //avoid null, thus avoiding nullpointerException
        for (int i = 0; i < other.size; i++) {
            insert(other.heap[i].getKey(), other.heap[i].getValue());
        }
    }

    //helper method to swap
    private void swap(int i, int j) {
        Entry<K, V> temp = heap[i];
        heap[i] = heap[j];
        heap[j] = temp;
    }

    //adding at the bottom of the heap
    public void upHeap(int index){
        //if there is a child
        while(index > 0){
            int parent =(index-1)/2;
            //comparing the keys of two entries in the heap, current node and the parent node
            int compare = heap[index].getKey().compareTo(heap[parent].getKey());
            //for the minHeap, bubble up if child>parent
            //for the maxHeap, bubble up if child>parent
            if(isMinHeap && compare < 0|| !isMinHeap && compare > 0){
                swap(index,parent);
                index = parent;
            }
            else{
                break;
            }

        }
    }

    //adding at the top of the heap
    public void downHeap(int index){
        while(index<size){
           int left = index*2+1;
           int right = index*2+2;
           int target = index;

           //check for the left child
           if(left< size){
               //comparing left child with parent
               int CompareLeft = heap[left].getKey().compareTo(heap[target].getKey());
               // if it is a minHeap and left child is smaller update the target
               //if it is a maxHeap and the left child is larger update target
               if((isMinHeap && CompareLeft < 0)|| (!isMinHeap && CompareLeft > 0)){
                   target = left;
               }
           }

           if(right< size){
               int CompareRight = heap[right].getKey().compareTo(heap[target].getKey());
               // if it is a minHeap and right child is smaller update the target
               //if it is a maxHeap and the right child is larger update target
               if((isMinHeap && CompareRight < 0)|| (!isMinHeap && CompareRight > 0)){
                   target = right;
               }
           }

            //after checking both left and right index if everything is fine do nothing
           if(target == index){
               break;
           }

           swap(index,target);
           index = target;
        }

    }

    //nested Entry class
    public static class Entry<K, V> {
        private K key;
        private V value;

        public Entry(K key, V value) {
            this.key = key;
            this.value = value;
        }

        public K getKey() {
            return key;
        }

        //normally we should avoid using a setter for the key since, we dont change the key of entry once its inserted however we will need it for the replaceKey method
        public void setKey(K key) {
            this.key = key;
        }

        public V getValue() {
            return value;
        }

        public void setValue(V value) {
            this.value = value;
        }
    }
}